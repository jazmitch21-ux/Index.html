# North Star Bakery Website

Static, mobile-friendly four-page website ready for GitHub Pages.

## Publish with GitHub Pages
1. Create a public GitHub repository (for example `north-star-bakery`).
2. Upload **the contents of this folder** to the repository root, including `assets/`.
3. Open **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**, branch **main**, folder **/(root)**, then **Save**.
4. Your website will be available at `https://YOUR-USERNAME.github.io/north-star-bakery/` once deployment completes.

## Before publishing
- The contact form is only a demo. It **does not send submissions**. Connect a form service before accepting requests.
- Verify business hours, prices, and business details.
- Product images are cropped from the user-supplied design mockup; replace them with original product photos for sharper visuals.
- No audio/video files were supplied, so those nonfunctional media players were removed.
